﻿using SistemaGestionUniversitaria.App;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
 
namespace SistemaGestionUniversitaria
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            Console.OutputEncoding = System.Text.Encoding.UTF8;

            Console.WriteLine("==============================================");
            Console.WriteLine("      SISTEMA DE GESTION UNIVERSITARIA");
            Console.WriteLine("==============================================");
            Console.WriteLine("1. Iniciar sesión");
            Console.WriteLine("2. Demo");
            Console.WriteLine("3. Salir");

            Console.Write("Seleccione una opción: ");
            string opcion = Console.ReadLine();

            if (opcion == "1")
            {
                if (!Autenticacion.IniciarSesion())
                {
                    Console.WriteLine("El programa se cerrará.");
                    return;
                }

                Menu menu = new Menu();
                menu.Iniciar();
            }
            else if (opcion == "2")
            {
                DemoPruebas.Ejecutar();
            }
            else
            {
                Console.WriteLine("Saliendo...");
            }
        }
    }
}