﻿using SistemaGestionUniversitaria.Exepciones;
using SistemaGestionUniversitaria.Modelo;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SistemaGestionUniversitaria.Servicio
{
    public class ServicioProfesores
    {
        private List<Profesor> profesores;

        public ServicioProfesores()
        {
            profesores = new List<Profesor>();
        }

        public ServicioProfesores(List<Profesor> lista)
        {
            profesores = lista ?? new List<Profesor>();
        }

        public List<Profesor> ListarTodos()
        {
            return profesores;
        }

        public Profesor BuscarPorDocumento(string documento)
        {
            if (string.IsNullOrWhiteSpace(documento))
                return null;

            foreach (Profesor p in profesores)
            {
                if (string.Equals(p.Documento, documento.Trim(), StringComparison.OrdinalIgnoreCase))
                    return p;
            }

            return null;
        }

        public void Agregar(Profesor profesor)
        {
            if (profesor == null)
                throw new ArgumentNullException("profesor");

            if (BuscarPorDocumento(profesor.Documento) != null)
                throw new ProfesorDuplicadoException(profesor.Documento);

            profesores.Add(profesor);
        }

        public void Editar(string documento, string nombre, string correo, string especialidad)
        {
            Profesor profesor = BuscarPorDocumento(documento);
            if (profesor == null)
                throw new InvalidOperationException("No existe el profesor.");

            if (!profesor.Activo)
                throw new InvalidOperationException("No se puede editar un profesor inactivo. Reactívelo primero.");

            profesor.Nombre = nombre;
            profesor.Correo = correo;
            profesor.Especialidad = especialidad;
        }

        public void EliminarLogico(string documento)
        {
            Profesor profesor = BuscarPorDocumento(documento);
            if (profesor == null)
                throw new InvalidOperationException("No existe el profesor.");

            if (!profesor.Activo)
                throw new InvalidOperationException("El profesor ya está inactivo.");

            profesor.Activo = false;
        }

        public void Reactivar(string documento)
        {
            Profesor profesor = BuscarPorDocumento(documento);
            if (profesor == null)
                throw new InvalidOperationException("No existe el profesor.");

            if (profesor.Activo)
                throw new InvalidOperationException("El profesor ya está activo.");

            profesor.Activo = true;
        }

        public List<Profesor> FiltrarPorEstado(bool activo)
        {
            List<Profesor> resultado = new List<Profesor>();

            foreach (Profesor p in profesores)
            {
                if (p.Activo == activo)
                    resultado.Add(p);
            }

            return resultado;
        }
    }
}