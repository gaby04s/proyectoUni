﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SistemaGestionUniversitaria.Servicio
{

    public class ServicioPersistencia
    {
        public string ExportarTodo(List<string> lineas, string nombreArchivo)
        {
            string ruta = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, nombreArchivo);
            using (StreamWriter escritor = new StreamWriter(ruta, false, Encoding.UTF8))
            {
                foreach (string linea in lineas)
                {
                    escritor.WriteLine(linea);
                }
            }

            return ruta;
        }
    }
}
