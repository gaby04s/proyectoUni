﻿using SistemaGestionUniversitaria.Exepciones;
using SistemaGestionUniversitaria.Modelo;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SistemaGestionUniversitaria.Servicio
{
    public class ServicioCursos
    {
        private List<Curso> cursos;

        public ServicioCursos()
        {
            cursos = new List<Curso>();
        }

        public ServicioCursos(List<Curso> lista)
        {
            cursos = lista ?? new List<Curso>();
        }

        public List<Curso> ListarTodos()
        {
            return cursos;
        }

        public Curso BuscarPorCodigo(string codigo)
        {
            if (string.IsNullOrWhiteSpace(codigo))
                return null;

            foreach (Curso c in cursos)
            {
                if (string.Equals(c.Codigo, codigo.Trim(), StringComparison.OrdinalIgnoreCase))
                    return c;
            }

            return null;
        }

        public void Agregar(Curso curso)
        {
            if (curso == null)
                throw new ArgumentNullException("curso");

            if (BuscarPorCodigo(curso.Codigo) != null)
                throw new CursoDuplicadoException(curso.Codigo);

            cursos.Add(curso);
        }

        public void Editar(string codigo, string nombre, int creditos, string carrera)
        {
            Curso curso = BuscarPorCodigo(codigo);
            if (curso == null)
                throw new InvalidOperationException("No existe el curso.");

            if (!curso.Activo)
                throw new InvalidOperationException("No se puede editar un curso inactivo. Reactívalo primero.");

            curso.Nombre = nombre;
            curso.Creditos = creditos;
            curso.Carrera = carrera;
        }

        public void EliminarLogico(string codigo)
        {
            Curso curso = BuscarPorCodigo(codigo);
            if (curso == null)
                throw new InvalidOperationException("No existe el curso.");

            if (!curso.Activo)
                throw new InvalidOperationException("El curso ya está inactivo.");

            curso.Activo = false;
        }

        public void Reactivar(string codigo)
        {
            Curso curso = BuscarPorCodigo(codigo);
            if (curso == null)
                throw new InvalidOperationException("No existe el curso.");

            if (curso.Activo)
                throw new InvalidOperationException("El curso ya está activo.");

            curso.Activo = true;
        }

        public List<Curso> FiltrarPorEstado(bool activo)
        {
            List<Curso> resultado = new List<Curso>();

            foreach (Curso c in cursos)
            {
                if (c.Activo == activo)
                    resultado.Add(c);
            }

            return resultado;
        }
    }
}