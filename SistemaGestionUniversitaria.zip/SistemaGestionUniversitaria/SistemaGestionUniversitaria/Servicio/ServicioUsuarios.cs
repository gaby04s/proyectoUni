﻿using SistemaGestionUniversitaria.Exepciones;
using SistemaGestionUniversitaria.Modelo;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SistemaGestionUniversitaria.Servicio
{
    public class ServicioUsuarios
    {
        private List<Usuario> usuarios;

        public ServicioUsuarios()
        {
            usuarios = new List<Usuario>();
        }

        public ServicioUsuarios(List<Usuario> lista)
        {
            usuarios = lista ?? new List<Usuario>();
        }

        public List<Usuario> ListarTodos()
        {
            return usuarios;
        }

        public Usuario Buscar(string nombreUsuario)
        {
            if (string.IsNullOrWhiteSpace(nombreUsuario))
                return null;

            foreach (Usuario u in usuarios)
            {
                if (string.Equals(u.NombreUsuario, nombreUsuario.Trim(), StringComparison.OrdinalIgnoreCase))
                    return u;
            }

            return null;
        }

        public void Agregar(Usuario usuario)
        {
            if (usuario == null)
                throw new ArgumentNullException("usuario");

            if (Buscar(usuario.NombreUsuario) != null)
                throw new UsuarioDuplicadoException(usuario.NombreUsuario);

            usuarios.Add(usuario);
        }

        public void CambiarEstado(string nombreUsuario, bool activo)
        {
            Usuario usuario = Buscar(nombreUsuario);
            if (usuario == null)
                throw new InvalidOperationException("No existe el usuario.");

            usuario.CambiarEstado(activo);
        }

        public void EliminarLogico(string nombreUsuario)
        {
            Usuario usuario = Buscar(nombreUsuario);
            if (usuario == null)
                throw new InvalidOperationException("No existe el usuario.");

            if (!usuario.Activo)
                throw new InvalidOperationException("El usuario ya está inactivo.");

            usuario.CambiarEstado(false);
        }

        public void Reactivar(string nombreUsuario)
        {
            Usuario usuario = Buscar(nombreUsuario);
            if (usuario == null)
                throw new InvalidOperationException("No existe el usuario.");

            if (usuario.Activo)
                throw new InvalidOperationException("El usuario ya está activo.");

            usuario.CambiarEstado(true);
        }

        public bool Existe(string nombreUsuario)
        {
            return Buscar(nombreUsuario) != null;
        }
    }
}