﻿using SistemaGestionUniversitaria.Modelo;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SistemaGestionUniversitaria.Servicio
{
    public class ServicioInscripciones
    {
        private List<Inscripcion> inscripciones;

        public ServicioInscripciones()
        {
            inscripciones = new List<Inscripcion>();
        }

        public ServicioInscripciones(List<Inscripcion> lista)
        {
            inscripciones = lista ?? new List<Inscripcion>();
        }

        public List<Inscripcion> ListarTodos()
        {
            return inscripciones;
        }

        public void Agregar(Inscripcion inscripcion)
        {
            if (inscripcion == null)
                throw new ArgumentNullException("inscripcion");

            inscripciones.Add(inscripcion);
        }

        public Inscripcion Buscar(string documentoEstudiante, string codigoCurso)
        {
            foreach (Inscripcion i in inscripciones)
            {
                if (string.Equals(i.DocumentoEstudiante, documentoEstudiante.Trim(), StringComparison.OrdinalIgnoreCase)
                    && string.Equals(i.CodigoCurso, codigoCurso.Trim(), StringComparison.OrdinalIgnoreCase))
                {
                    return i;
                }
            }

            return null;
        }

        public void RegistrarNota(string documentoEstudiante, string codigoCurso, decimal nota)
        {
            Inscripcion inscripcion = Buscar(documentoEstudiante, codigoCurso);
            if (inscripcion == null)
                throw new InvalidOperationException("El estudiante no está inscrito en ese curso.");

            inscripcion.AgregarNota(nota);
        }

        public void EliminarLogico(string documentoEstudiante, string codigoCurso)
        {
            Inscripcion inscripcion = Buscar(documentoEstudiante, codigoCurso);
            if (inscripcion == null)
                throw new InvalidOperationException("No existe la inscripción.");

            inscripcion.Activo = false;
        }

        public void Reactivar(string documentoEstudiante, string codigoCurso)
        {
            Inscripcion inscripcion = Buscar(documentoEstudiante, codigoCurso);
            if (inscripcion == null)
                throw new InvalidOperationException("No existe la inscripción.");

            inscripcion.Activo = true;
        }
    }
}