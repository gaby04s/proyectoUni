﻿using SistemaGestionUniversitaria.Exepciones;
using SistemaGestionUniversitaria.Modelo;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SistemaGestionUniversitaria.Servicio
{
    public class ServicioEstudiantes
    {
        private List<Estudiante> estudiantes;

        public ServicioEstudiantes()
        {
            estudiantes = new List<Estudiante>();
        }

        public ServicioEstudiantes(List<Estudiante> lista)
        {
            estudiantes = lista ?? new List<Estudiante>();
        }

        public List<Estudiante> ListarTodos()
        {
            return estudiantes;
        }

        public Estudiante BuscarPorDocumento(string documento)
        {
            if (string.IsNullOrWhiteSpace(documento))
                return null;

            foreach (Estudiante e in estudiantes)
            {
                if (string.Equals(e.Documento, documento.Trim(), StringComparison.OrdinalIgnoreCase))
                    return e;
            }

            return null;
        }

        public void Agregar(Estudiante estudiante)
        {
            if (estudiante == null)
                throw new ArgumentNullException("estudiante");

            if (BuscarPorDocumento(estudiante.Documento) != null)
                throw new EstudianteDuplicadoException(estudiante.Documento);

            estudiantes.Add(estudiante);
        }

        public void Editar(string documento, string nombre, string correo, int edad, string carrera)
        {
            Estudiante estudiante = BuscarPorDocumento(documento);
            if (estudiante == null)
                throw new InvalidOperationException("No existe el estudiante.");

            if (!estudiante.Activo)
                throw new InvalidOperationException("No se puede editar un estudiante inactivo. Reactívelo primero.");

            estudiante.Nombre = nombre;
            estudiante.Correo = correo;
            estudiante.Edad = edad;
            estudiante.Carrera = carrera;
        }

        public void EliminarLogico(string documento)
        {
            Estudiante estudiante = BuscarPorDocumento(documento);
            if (estudiante == null)
                throw new InvalidOperationException("No existe el estudiante.");

            if (!estudiante.Activo)
                throw new InvalidOperationException("El estudiante ya está inactivo.");

            estudiante.Activo = false;
        }

        public void Reactivar(string documento)
        {
            Estudiante estudiante = BuscarPorDocumento(documento);
            if (estudiante == null)
                throw new InvalidOperationException("No existe el estudiante.");

            if (estudiante.Activo)
                throw new InvalidOperationException("El estudiante ya está activo.");

            estudiante.Activo = true;
        }

        public List<Estudiante> FiltrarPorEstado(bool activo)
        {
            List<Estudiante> resultado = new List<Estudiante>();

            foreach (Estudiante e in estudiantes)
            {
                if (e.Activo == activo)
                    resultado.Add(e);
            }

            return resultado;
        }
    }
}