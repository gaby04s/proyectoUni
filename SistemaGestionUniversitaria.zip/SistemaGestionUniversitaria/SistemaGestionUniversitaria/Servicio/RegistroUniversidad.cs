﻿using SistemaGestionUniversitaria.Modelo;
using SistemaGestionUniversitaria.Persistencia;
using SistemaGestionUniversitaria.Utilidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SistemaGestionUniversitaria.Servicio
{
    public class RegistroUniversidad
    {
        private DatosSistema datos;

        public ServicioUsuarios ServicioUsuarios { get; private set; }
        public ServicioEstudiantes ServicioEstudiantes { get; private set; }
        public ServicioProfesores ServicioProfesores { get; private set; }
        public ServicioCursos ServicioCursos { get; private set; }
        public ServicioInscripciones ServicioInscripciones { get; private set; }

        public RegistroUniversidad()
        {
            datos = ArchivoDatos.Cargar();

            ServicioUsuarios = new ServicioUsuarios(datos.Usuarios);
            ServicioEstudiantes = new ServicioEstudiantes(datos.Estudiantes);
            ServicioProfesores = new ServicioProfesores(datos.Profesores);
            ServicioCursos = new ServicioCursos(datos.Cursos);
            ServicioInscripciones = new ServicioInscripciones(datos.Inscripciones);

            CrearUsuarioInicialSiNoExiste();
            Guardar();
        }

        public void CrearUsuarioInicialSiNoExiste()
        {
            Usuario usuario = ServicioUsuarios.Buscar("Victor");

            if (usuario == null)
            {
                Usuario inicial = new Usuario("Victor", "Vl22050*/", "Administrador", true);
                ServicioUsuarios.Agregar(inicial);
                Log.Registrar("Victor", "CREAR_USUARIO_INICIAL", "Victor", "Se creó el primer usuario del sistema.");
            }
        }

        public void Guardar()
        {
            datos.Usuarios = ServicioUsuarios.ListarTodos();
            datos.Estudiantes = ServicioEstudiantes.ListarTodos();
            datos.Profesores = ServicioProfesores.ListarTodos();
            datos.Cursos = ServicioCursos.ListarTodos();
            datos.Inscripciones = ServicioInscripciones.ListarTodos();

            ArchivoDatos.Guardar(datos);
        }

        public bool ValidarLogin(string usuario, string contrasena)
        {
            Usuario cuenta = ServicioUsuarios.Buscar(usuario);
            if (cuenta == null)
                return false;

            return cuenta.Activo && cuenta.ValidarCredenciales(usuario, contrasena);
        }

        public void AgregarUsuario(Usuario usuario)
        {
            ServicioUsuarios.Agregar(usuario);
            Guardar();
            Log.Registrar("Victor", "AGREGAR_USUARIO", usuario.NombreUsuario, "Se agregó un usuario.");
        }

        public void DesactivarUsuario(string nombreUsuario)
        {
            ServicioUsuarios.EliminarLogico(nombreUsuario);
            Guardar();
            Log.Registrar("Victor", "DESACTIVAR_USUARIO", nombreUsuario, "Se desactivó el usuario.");
        }

        public void ReactivarUsuario(string nombreUsuario)
        {
            ServicioUsuarios.Reactivar(nombreUsuario);
            Guardar();
            Log.Registrar("Victor", "REACTIVAR_USUARIO", nombreUsuario, "Se reactivó el usuario.");
        }

        public List<Usuario> ListarUsuarios()
        {
            return ServicioUsuarios.ListarTodos();
        }

        public List<Estudiante> ListarEstudiantes()
        {
            return ServicioEstudiantes.ListarTodos();
        }

        public List<Profesor> ListarProfesores()
        {
            return ServicioProfesores.ListarTodos();
        }

        public List<Curso> ListarCursos()
        {
            return ServicioCursos.ListarTodos();
        }

        public Estudiante BuscarEstudiante(string documento)
        {
            return ServicioEstudiantes.BuscarPorDocumento(documento);
        }

        public Profesor BuscarProfesor(string documento)
        {
            return ServicioProfesores.BuscarPorDocumento(documento);
        }

        public Curso BuscarCurso(string codigo)
        {
            return ServicioCursos.BuscarPorCodigo(codigo);
        }

        public void AgregarEstudiante(Estudiante estudiante)
        {
            ServicioEstudiantes.Agregar(estudiante);
            Guardar();
            Log.Registrar("Victor", "AGREGAR_ESTUDIANTE", estudiante.Documento, "Se agregó un estudiante.");
        }

        public void EditarEstudiante(string documento, string nombre, string correo, int edad, string carrera)
        {
            ServicioEstudiantes.Editar(documento, nombre, correo, edad, carrera);
            Guardar();
            Log.Registrar("Victor", "EDITAR_ESTUDIANTE", documento, "Se editó el estudiante.");
        }

        public void DesactivarEstudiante(string documento)
        {
            ServicioEstudiantes.EliminarLogico(documento);
            Guardar();
            Log.Registrar("Victor", "DESACTIVAR_ESTUDIANTE", documento, "Se desactivó el estudiante.");
        }

        public void ReactivarEstudiante(string documento)
        {
            ServicioEstudiantes.Reactivar(documento);
            Guardar();
            Log.Registrar("Victor", "REACTIVAR_ESTUDIANTE", documento, "Se reactivó el estudiante.");
        }

        public void AgregarProfesor(Profesor profesor)
        {
            ServicioProfesores.Agregar(profesor);
            Guardar();
            Log.Registrar("Victor", "AGREGAR_PROFESOR", profesor.Documento, "Se agregó un profesor.");
        }

        public void EditarProfesor(string documento, string nombre, string correo, string especialidad)
        {
            ServicioProfesores.Editar(documento, nombre, correo, especialidad);
            Guardar();
            Log.Registrar("Victor", "EDITAR_PROFESOR", documento, "Se editó el profesor.");
        }

        public void DesactivarProfesor(string documento)
        {
            ServicioProfesores.EliminarLogico(documento);
            Guardar();
            Log.Registrar("Victor", "DESACTIVAR_PROFESOR", documento, "Se desactivó el profesor.");
        }

        public void ReactivarProfesor(string documento)
        {
            ServicioProfesores.Reactivar(documento);
            Guardar();
            Log.Registrar("Victor", "REACTIVAR_PROFESOR", documento, "Se reactivó el profesor.");
        }

        public void AgregarCurso(Curso curso)
        {
            ServicioCursos.Agregar(curso);
            Guardar();
            Log.Registrar("Victor", "AGREGAR_CURSO", curso.Codigo, "Se agregó un curso.");
        }

        public void EditarCurso(string codigo, string nombre, int creditos, string carrera)
        {
            ServicioCursos.Editar(codigo, nombre, creditos, carrera);
            Guardar();
            Log.Registrar("Victor", "EDITAR_CURSO", codigo, "Se editó el curso.");
        }

        public void DesactivarCurso(string codigo)
        {
            ServicioCursos.EliminarLogico(codigo);
            Guardar();
            Log.Registrar("Victor", "DESACTIVAR_CURSO", codigo, "Se desactivó el curso.");
        }

        public void ReactivarCurso(string codigo)
        {
            ServicioCursos.Reactivar(codigo);
            Guardar();
            Log.Registrar("Victor", "REACTIVAR_CURSO", codigo, "Se reactivó el curso.");
        }

        public void AgregarInscripcion(Inscripcion inscripcion)
        {
            ServicioInscripciones.Agregar(inscripcion);
            Guardar();
            Log.Registrar("Victor", "AGREGAR_INSCRIPCION", inscripcion.DocumentoEstudiante + "-" + inscripcion.CodigoCurso,
                "Se registró una inscripción.");
        }

        public void RegistrarNota(string documentoEstudiante, string codigoCurso, decimal nota)
        {
            ServicioInscripciones.RegistrarNota(documentoEstudiante, codigoCurso, nota);
            Guardar();
            Log.Registrar("Victor", "REGISTRAR_NOTA", documentoEstudiante + "-" + codigoCurso,
                "Se registró la nota " + nota);
        }

        public List<string> ExportarEstudiantes(bool activos, bool inactivos)
        {
            List<string> lineas = new List<string>();
            foreach (Estudiante e in ServicioEstudiantes.ListarTodos())
            {
                if ((activos && e.Activo) || (inactivos && !e.Activo) || (!activos && !inactivos))
                {
                    lineas.Add("ESTUDIANTE; " + e.Documento + "; " + e.Nombre + "; " + e.Correo + "; " + e.Carrera + "; " + (e.Activo ? "Activo" : "Inactivo"));
                }
            }

            return lineas;
        }

        public List<string> ExportarProfesores(bool activos, bool inactivos)
        {
            List<string> lineas = new List<string>();
            foreach (Profesor p in ServicioProfesores.ListarTodos())
            {
                if ((activos && p.Activo) || (inactivos && !p.Activo) || (!activos && !inactivos))
                {
                    lineas.Add("PROFESOR; " + p.Documento + "; " + p.Nombre + "; " + p.Correo + "; " + p.Especialidad + "; " + (p.Activo ? "Activo" : "Inactivo"));
                }
            }

            return lineas;
        }

        public List<string> ExportarTodo(bool activos, bool inactivos)
        {
            List<string> lineas = new List<string>();
            foreach (Estudiante e in ServicioEstudiantes.ListarTodos())
            {
                if ((activos && e.Activo) || (inactivos && !e.Activo) || (!activos && !inactivos))
                    lineas.Add("ESTUDIANTE; " + e.Documento + "; " + e.Nombre + "; " + e.Correo + "; " + e.Carrera + "; " + (e.Activo ? "Activo" : "Inactivo"));
            }

            foreach (Profesor p in ServicioProfesores.ListarTodos())
            {
                if ((activos && p.Activo) || (inactivos && !p.Activo) || (!activos && !inactivos))
                    lineas.Add("PROFESOR; " + p.Documento + "; " + p.Nombre + "; " + p.Correo + "; " + p.Especialidad + "; " + (p.Activo ? "Activo" : "Inactivo"));
            }

            foreach (Curso c in ServicioCursos.ListarTodos())
            {
                if ((activos && c.Activo) || (inactivos && !c.Activo) || (!activos && !inactivos))
                    lineas.Add("CURSO; " + c.Codigo + "; " + c.Nombre + "; " + c.Creditos + "; " + c.Carrera + "; " + (c.Activo ? "Activo" : "Inactivo"));
            }

            return lineas;
        }

        public List<LogEntry> ObtenerLogs()
        {
            return ArchivoLogs.Cargar();
        }
    }
}