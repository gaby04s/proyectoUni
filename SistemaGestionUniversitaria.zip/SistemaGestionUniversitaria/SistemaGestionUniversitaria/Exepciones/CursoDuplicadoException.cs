﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SistemaGestionUniversitaria.Exepciones
{
    public class CursoDuplicadoException : UniversidadException
    {
        public CursoDuplicadoException(string codigo)
            : base("Ya existe un curso con el código " + codigo + ".")
        {
        }
    }
}