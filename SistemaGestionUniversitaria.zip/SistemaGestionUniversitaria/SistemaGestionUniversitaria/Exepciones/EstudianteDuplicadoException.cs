﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SistemaGestionUniversitaria.Exepciones
{
    public class EstudianteDuplicadoException : UniversidadException
    {
        public EstudianteDuplicadoException(string documento)
            : base("Ya existe un estudiante con la identificación " +
                   documento + ".")
        {
        }
    }
}
