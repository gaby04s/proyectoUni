﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SistemaGestionUniversitaria.Exepciones
{
    public class UsuarioDuplicadoException : UniversidadException
    {
        public UsuarioDuplicadoException(string nombreUsuario)
            : base("Ya existe el usuario: " + nombreUsuario + ".")
        {
        }
    }
}
