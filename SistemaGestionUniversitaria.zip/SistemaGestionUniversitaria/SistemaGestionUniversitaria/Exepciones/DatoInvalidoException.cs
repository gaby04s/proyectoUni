﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SistemaGestionUniversitaria.Exepciones
{
    public class DatoInvalidoException : UniversidadException
    {
        public DatoInvalidoException(string mensaje)
            : base(mensaje)
        {
        }
    }
}