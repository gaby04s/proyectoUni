﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SistemaGestionUniversitaria.Exepciones
{
    public class ProfesorDuplicadoException : UniversidadException
    {
        public ProfesorDuplicadoException(string documento)
            : base("Ya existe un profesor con la identificación " +
                   documento + ".")
        {
        }
    }
}