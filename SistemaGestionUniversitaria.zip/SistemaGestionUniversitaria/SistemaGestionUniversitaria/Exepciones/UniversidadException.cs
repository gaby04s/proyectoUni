﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SistemaGestionUniversitaria.Exepciones
{
    public class UniversidadException : Exception
    {
        public UniversidadException(string mensaje)
            : base(mensaje)
        {
        }

        public UniversidadException(string mensaje, Exception innerException)
            : base(mensaje, innerException)
        {
        }
    }
}
