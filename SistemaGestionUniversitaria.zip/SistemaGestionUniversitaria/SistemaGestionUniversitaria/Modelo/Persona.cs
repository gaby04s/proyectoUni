﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks; //cLASE PADRE : concentra los datos comunes. Estudiante y Profesor heredan esos elementos
                              //, mientras cada clase mantiene sus datos específicos. Esto evita repetir los campos comunes.”

//se OBSERVA LAS CLASES ABSTRACTAS : es abstracta porque el sistema no registra personas genéricas:
//registra personas con un rol concreto, como estudiante o profesor.”
namespace SistemaGestionUniversitaria.Modelo
{
    [Serializable]
    public abstract class Persona
    {
        public string Nombre { get; set; }
        public string Documento { get; set; }
        public string Correo { get; set; }
        public bool Activo { get; set; }

        protected Persona(string nombre, string documento, string correo)
        {
            Nombre = nombre;
            Documento = documento;
            Correo = correo;
            Activo = true;
        }

        public abstract string ObtenerRol();

        public virtual string GenerarResumen()
        {
            return "Nombre: " + Nombre +
                   " | Documento: " + Documento +
                   " | Correo: " + Correo +
                   " | Estado: " + (Activo ? "Activo" : "Inactivo");
        }

        public override string ToString()
        {
            return GenerarResumen();
        }
    }
}