﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SistemaGestionUniversitaria.Modelo
{
    [Serializable]
    public class Inscripcion
    {
        public string DocumentoEstudiante { get; set; }
        public string CodigoCurso { get; set; }
        public List<decimal> Notas { get; set; }
        public bool Activo { get; set; }

        public Inscripcion(string documentoEstudiante, string codigoCurso)
        {
            if (string.IsNullOrWhiteSpace(documentoEstudiante))
                throw new ArgumentException("El documento del estudiante es obligatorio.");

            if (string.IsNullOrWhiteSpace(codigoCurso))
                throw new ArgumentException("El código del curso es obligatorio.");

            DocumentoEstudiante = documentoEstudiante.Trim();
            CodigoCurso = codigoCurso.Trim();
            Notas = new List<decimal>();
            Activo = true;
        }

        public void AgregarNota(decimal nota)
        {
            if (nota < 0 || nota > 100)
                throw new ArgumentOutOfRangeException("nota", "La nota debe estar entre 0 y 100.");

            Notas.Add(nota);
        }

        public decimal ObtenerPromedio()
        {
            if (Notas.Count == 0)
                return 0;

            decimal suma = 0;
            foreach (decimal nota in Notas)
            {
                suma += nota;
            }

            return suma / Notas.Count;
        }

        public override string ToString()
        {
            return "Inscripción: " + DocumentoEstudiante + " -> " + CodigoCurso +
                   " | Promedio: " + ObtenerPromedio();
        }
    }
}