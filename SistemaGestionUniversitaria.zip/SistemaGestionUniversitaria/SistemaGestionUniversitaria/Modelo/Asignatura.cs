﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SistemaGestionUniversitaria.Modelo
{
    [Serializable]
    public class Asignatura
    {
        public string Nombre { get; set; }
        public int Horas { get; set; }

        public Asignatura(string nombre, int horas)
        {
            if (string.IsNullOrWhiteSpace(nombre))
                throw new ArgumentException("El nombre de la asignatura es obligatorio.");

            if (horas <= 0)
                throw new ArgumentException("Las horas deben ser mayores que cero.");

            Nombre = nombre.Trim();
            Horas = horas;
        }

        public override string ToString()
        {
            return Nombre + " (" + Horas + " horas)";
        }
    }
}