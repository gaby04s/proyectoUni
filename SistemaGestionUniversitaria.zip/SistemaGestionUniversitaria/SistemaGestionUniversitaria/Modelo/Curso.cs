﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SistemaGestionUniversitaria.Validacion;
namespace SistemaGestionUniversitaria.Modelo
{
    [Serializable]
    public class Curso
    {
        public string Codigo { get; set; }
        public string Nombre { get; set; }
        public int Creditos { get; set; }
        public string Carrera { get; set; }
        public bool Activo { get; set; }

        public Curso(string codigo, string nombre, int creditos, string carrera)
        {
            Codigo = NormalizadorTexto.ValidarObligatorio(
        codigo, "El código del curso", 2, 15);

            if (!System.Text.RegularExpressions.Regex.IsMatch(
                    Codigo, @"^[A-Za-z0-9-]+$"))
            {
                throw new ArgumentException(
                    "El código del curso solo puede contener letras, números y guiones.");
            }

            Nombre = NormalizadorTexto.ValidarDescripcion(
                nombre, "El nombre del curso");

            Carrera = NormalizadorTexto.ValidarDescripcion(
                carrera, "La carrera");

            if (creditos < 1 || creditos > 30)
            {
                throw new ArgumentOutOfRangeException(
                    "creditos",
                    "Los créditos deben estar entre 1 y 30.");
            }

            Creditos = creditos;
            Activo = true;
        }
    }
}