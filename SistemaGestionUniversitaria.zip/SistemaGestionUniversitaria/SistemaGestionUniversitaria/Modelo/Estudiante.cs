﻿using SistemaGestionUniversitaria.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SistemaGestionUniversitaria.Modelo //CLASE HIJA DE PERSONA , HEREDA LOS CAMPOS, COMO NOMBRE, DOCUMENTO, CORREO ENTREOTRSO
{
    [Serializable]
    public class Estudiante : Persona, IReportable
    {
        public int Edad { get; set; }
        public string Carrera { get; set; }
        public List<Inscripcion> Inscripciones { get; set; }

        public Estudiante(string nombre, string documento, string correo, int edad, string carrera)
            : base(nombre, documento, correo)
        {
            if (edad < 15 || edad > 100)
                throw new ArgumentOutOfRangeException("edad", "La edad debe estar entre 15 y 100 años.");

            if (string.IsNullOrWhiteSpace(carrera))
                throw new ArgumentException("La carrera es obligatoria.");

            Edad = edad;
            Carrera = carrera.Trim();
            Inscripciones = new List<Inscripcion>();
        }

        public override string ObtenerRol()
        {
            return "Estudiante";
        }

        public string GenerarReporte()
        {
            return GenerarResumen();
        }

        public override string GenerarResumen()
        {
            return base.GenerarResumen() +
                   " | Rol: " + ObtenerRol() +
                   " | Edad: " + Edad +
                   " | Carrera: " + Carrera;
        }
    }
}