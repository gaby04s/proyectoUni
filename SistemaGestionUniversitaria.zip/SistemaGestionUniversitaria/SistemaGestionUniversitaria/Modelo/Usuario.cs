﻿using SistemaGestionUniversitaria.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace SistemaGestionUniversitaria.Modelo
{
    [Serializable]
    public class Usuario : IAutenticable
    {
        public string NombreUsuario { get; set; }
        public string ContrasenaHash { get; set; }
        public string Rol { get; set; }
        public bool Activo { get; set; }
        public bool EsUsuarioInicialProtegido { get; set; }

        public Usuario(string nombreUsuario, string contrasena, string rol, bool esUsuarioInicialProtegido)
        {
            if (string.IsNullOrWhiteSpace(nombreUsuario))
                throw new ArgumentException("El nombre de usuario es obligatorio.");

            if (string.IsNullOrWhiteSpace(contrasena))
                throw new ArgumentException("La contraseña es obligatoria.");

            if (string.IsNullOrWhiteSpace(rol))
                throw new ArgumentException("El rol es obligatorio.");

            NombreUsuario = nombreUsuario.Trim();
            ContrasenaHash = CalcularHash(contrasena);
            Rol = rol.Trim();
            Activo = true;
            EsUsuarioInicialProtegido = esUsuarioInicialProtegido;
        }

        public bool ValidarCredenciales(string nombreUsuario, string contrasena)
        {
            if (!Activo ||
                string.IsNullOrWhiteSpace(nombreUsuario) ||
                string.IsNullOrWhiteSpace(contrasena))
            {
                return false;
            }

            return string.Equals(NombreUsuario, nombreUsuario.Trim(), StringComparison.OrdinalIgnoreCase)
                && string.Equals(ContrasenaHash, CalcularHash(contrasena), StringComparison.Ordinal);
        }

        public void CambiarEstado(bool activo)
        {
            if (EsUsuarioInicialProtegido && !activo)
                throw new InvalidOperationException("El usuario protegido no puede desactivarse.");

            Activo = activo;
        }

        private static string CalcularHash(string texto)
        {
            using (SHA256 sha = SHA256.Create())
            {
                byte[] bytes = Encoding.UTF8.GetBytes(texto);
                byte[] hash = sha.ComputeHash(bytes);
                return Convert.ToBase64String(hash);
            }
        }
    }
}