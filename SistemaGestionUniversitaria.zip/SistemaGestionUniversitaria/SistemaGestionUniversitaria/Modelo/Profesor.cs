﻿using SistemaGestionUniversitaria.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SistemaGestionUniversitaria.Modelo //Clase hija de persona 
{
    [Serializable]
    public class Profesor : Persona, IReportable
    {
        public string Especialidad { get; set; }

        public Profesor(string nombre, string documento, string correo, string especialidad)
            : base(nombre, documento, correo)
        {
            if (string.IsNullOrWhiteSpace(especialidad))
                throw new ArgumentException("La especialidad es obligatoria.");

            Especialidad = especialidad.Trim();
        }

        public override string ObtenerRol()
        {
            return "Profesor";
        }

        public string GenerarReporte()
        {
            return GenerarResumen();
        }

        public override string GenerarResumen()
        {
            return base.GenerarResumen() +
                   " | Rol: " + ObtenerRol() +
                   " | Especialidad: " + Especialidad;
        }
    }
}