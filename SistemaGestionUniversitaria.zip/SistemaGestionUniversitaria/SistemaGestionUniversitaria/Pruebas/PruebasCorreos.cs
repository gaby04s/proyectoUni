﻿using SistemaGestionUniversitaria.Validacion;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SistemaGestionUniversitaria.Pruebas
{
    public class PruebasCorreos
    {
        public static void Ejecutar()
        {
            Console.WriteLine("Prueba correo:");
            try
            {
                Console.WriteLine(ValidadorCorreo.Validar("ana@universidad.edu"));
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }
        }
    }
}