﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SistemaGestionUniversitaria.Pruebas
{
    public class PruebasInteractivas
    {
        public static void Ejecutar()
        {
            PruebasNombres.Ejecutar();
            PruebasCedulas.Ejecutar();
            PruebasCorreos.Ejecutar();
        }
    }
}