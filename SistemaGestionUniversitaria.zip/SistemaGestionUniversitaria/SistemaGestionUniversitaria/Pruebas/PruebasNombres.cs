﻿using SistemaGestionUniversitaria.Validacion;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SistemaGestionUniversitaria.Pruebas
{
    public class PruebasNombres
    {
        public static void Ejecutar()
        {
            Console.WriteLine("Prueba nombre:");
            try
            {
                Console.WriteLine(ValidadorNombre.Validar("Ana María"));
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }
        }
    }
}