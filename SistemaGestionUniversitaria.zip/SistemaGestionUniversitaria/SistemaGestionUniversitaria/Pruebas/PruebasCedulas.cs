﻿using SistemaGestionUniversitaria.Validacion;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SistemaGestionUniversitaria.Pruebas
{
    public class PruebasCedulas
    {
        public static void Ejecutar()
        {
            Console.WriteLine("Prueba cédula:");
            try
            {
                Console.WriteLine(ValidadorCedula.Validar("12345678"));
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }
        }
    }
}