﻿using SistemaGestionUniversitaria.Servicio;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SistemaGestionUniversitaria.Profesores
{
    public class DesactivarProfesor
    {
        public static void Ejecutar(RegistroUniversidad registro, string documento)
        {
            try
            {
                registro.DesactivarProfesor(documento);
                Console.WriteLine("Profesor desactivado.");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error al desactivar profesor: " + ex.Message);
            }
        }
    }
}