﻿using SistemaGestionUniversitaria.Modelo;
using SistemaGestionUniversitaria.Servicio;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SistemaGestionUniversitaria.Profesores
{
    public class ListarProfesores
    {
        public static void Ejecutar(RegistroUniversidad registro)
        {
            try
            {
                List<Profesor> profesores = registro.ListarProfesores();
                if (profesores.Count == 0)
                {
                    Console.WriteLine("No hay profesores registrados.");
                    return;
                }

                foreach (Profesor profesor in profesores)
                {
                    Console.WriteLine(profesor.GenerarResumen());
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error al listar profesores: " + ex.Message);
            }
        }
    }
}