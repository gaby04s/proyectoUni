﻿using SistemaGestionUniversitaria.Servicio;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SistemaGestionUniversitaria.Profesores
{
    public class ReactivarProfesor
    {
        public static void Ejecutar(RegistroUniversidad registro, string documento)
        {
            try
            {
                registro.ReactivarProfesor(documento);
                Console.WriteLine("Profesor reactivado.");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error al reactivar profesor: " + ex.Message);
            }
        }
    }
}