﻿using SistemaGestionUniversitaria.Modelo;
using SistemaGestionUniversitaria.Servicio;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SistemaGestionUniversitaria.Profesores
{
    public class AgregarProfesor
    {
        public static void Ejecutar(RegistroUniversidad registro, string nombre, string documento, string correo, string especialidad)
        {
            try
            {
                Profesor profesor = new Profesor(nombre, documento, correo, especialidad);
                registro.AgregarProfesor(profesor);
                Console.WriteLine("Profesor agregado.");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error al agregar profesor: " + ex.Message);
            }
        }
    }
}