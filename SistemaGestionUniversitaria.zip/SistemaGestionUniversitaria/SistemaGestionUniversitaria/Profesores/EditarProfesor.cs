﻿using SistemaGestionUniversitaria.Servicio;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SistemaGestionUniversitaria.Profesores
{
    public class EditarProfesor
    {
        public static void Ejecutar(RegistroUniversidad registro, string documento, string nombre, string correo, string especialidad)
        {
            try
            {
                registro.EditarProfesor(documento, nombre, correo, especialidad);
                Console.WriteLine("Profesor editado.");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error al editar profesor: " + ex.Message);
            }
        }
    }
}