﻿using SistemaGestionUniversitaria.Modelo;
using SistemaGestionUniversitaria.Servicio;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SistemaGestionUniversitaria.Profesores
{
    public class BuscarProfesor
    {
        public static void Ejecutar(RegistroUniversidad registro, string documento)
        {
            try
            {
                Profesor profesor = registro.BuscarProfesor(documento);
                if (profesor == null)
                {
                    Console.WriteLine("Profesor no encontrado.");
                    return;
                }

                Console.WriteLine(profesor.GenerarResumen());
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error al buscar profesor: " + ex.Message);
            }
        }
    }
}
