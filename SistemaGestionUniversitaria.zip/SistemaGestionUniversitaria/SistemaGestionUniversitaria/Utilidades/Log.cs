﻿using SistemaGestionUniversitaria.Persistencia;
using SistemaGestionUniversitaria.Modelo;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace SistemaGestionUniversitaria.Utilidades
{
    public static class Log
    {
        public static void Registrar(string usuario, string accion, string registroAfectado, string detalle)
        {
            try
            {
                ArchivoLogs.AgregarLog(new LogEntry
                {
                    FechaHora = DateTime.Now,
                    Usuario = usuario,
                    Accion = accion,
                    RegistroAfectado = registroAfectado,
                    Detalle = detalle
                });
            }
            catch
            {
                // No se cierra la app por fallos de log.
            }
        }

        public static void RegistrarLoginExitoso(string usuario)
        {
            Registrar(usuario, "LOGIN_EXITO", usuario, "Inicio de sesión correcto.");
        }

        public static void RegistrarLoginFallido(string usuario)
        {
            Registrar(usuario, "LOGIN_FALLIDO", usuario, "Intento de acceso fallido.");
        }

        public static void RegistrarCierreSesion(string usuario)
        {
            Registrar(usuario, "CERRAR_SESION", usuario, "Se cerró la sesión.");
        }
    }

    [Serializable]
    public class LogEntry
    {
        public DateTime FechaHora { get; set; }
        public string Usuario { get; set; }
        public string Accion { get; set; }
        public string RegistroAfectado { get; set; }
        public string Detalle { get; set; }

        public override string ToString()
        {
            return FechaHora.ToString("yyyy-MM-dd HH:mm:ss") +
                   " | Usuario: " + (Usuario ?? "desconocido") +
                   " | Acción: " + (Accion ?? "") +
                   " | Registro: " + (RegistroAfectado ?? "") +
                   " | Detalle: " + (Detalle ?? "");
        }
    }
}