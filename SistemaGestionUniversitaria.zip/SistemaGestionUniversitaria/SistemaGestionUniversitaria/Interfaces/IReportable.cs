﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SistemaGestionUniversitaria.Interfaces
{
    //Estudiante y ProfesorS
    public interface IReportable
    {
        string GenerarReporte();
    }
}
