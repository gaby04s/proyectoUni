﻿using SistemaGestionUniversitaria.Modelo;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SistemaGestionUniversitaria.Interfaces
{
    //“Las interfaces permiten que distintas clases ofrezcan una misma capacidad.Por ejemplo, estudiante y profesor pueden
    //generar reportes aunque tengan información diferente.”
    //uSUARIO
    public interface IAutenticable
    {
        bool ValidarCredenciales(string nombreUsuario, string contrasena);
    }
}
