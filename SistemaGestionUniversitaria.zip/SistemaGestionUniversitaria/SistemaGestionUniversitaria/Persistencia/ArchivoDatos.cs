﻿using SistemaGestionUniversitaria.Modelo;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;

namespace SistemaGestionUniversitaria.Persistencia
{
    public class DatosSistema
    {
        public List<Usuario> Usuarios { get; set; }
        public List<Estudiante> Estudiantes { get; set; }
        public List<Profesor> Profesores { get; set; }
        public List<Curso> Cursos { get; set; }
        public List<Inscripcion> Inscripciones { get; set; }

        public DatosSistema()
        {
            Usuarios = new List<Usuario>();
            Estudiantes = new List<Estudiante>();
            Profesores = new List<Profesor>();
            Cursos = new List<Curso>();
            Inscripciones = new List<Inscripcion>();
        }
    }

    public static class ArchivoDatos
    {
        public static string RutaArchivo = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "datosUniversidad.bin");

        public static DatosSistema Cargar()
        {
            DatosSistema datos = new DatosSistema();

            if (!File.Exists(RutaArchivo))
                return datos;

            try
            {
                using (BinaryReader reader = new BinaryReader(File.Open(RutaArchivo, FileMode.Open, FileAccess.Read)))
                {
                    int cantidadUsuarios = reader.ReadInt32();

                    for (int i = 0; i < cantidadUsuarios; i++)
                    {
                        string nombreUsuario = reader.ReadString();
                        string hash = reader.ReadString();
                        string rol = reader.ReadString();
                        bool protegido = reader.ReadBoolean();
                        bool activo = reader.ReadBoolean();

                        // El constructor calcula un hash, por eso se usa una contraseña
                        // temporal y luego se restaura el hash que ya estaba guardado.
                        Usuario usuario = new Usuario(
                            nombreUsuario,
                            "clave-temporal-de-carga",
                            rol,
                            protegido);

                        usuario.ContrasenaHash = hash;
                        usuario.EsUsuarioInicialProtegido = protegido;
                        usuario.Activo = activo;

                        datos.Usuarios.Add(usuario);
                    }

                    int cantidadEstudiantes = reader.ReadInt32();
                    for (int i = 0; i < cantidadEstudiantes; i++)
                    {
                        Estudiante estudiante = new Estudiante(
                            reader.ReadString(),
                            reader.ReadString(),
                            reader.ReadString(),
                            reader.ReadInt32(),
                            reader.ReadString());

                        estudiante.Activo = reader.ReadBoolean();
                        datos.Estudiantes.Add(estudiante);
                    }

                    int cantidadProfesores = reader.ReadInt32();
                    for (int i = 0; i < cantidadProfesores; i++)
                    {
                        Profesor profesor = new Profesor(
                            reader.ReadString(),
                            reader.ReadString(),
                            reader.ReadString(),
                            reader.ReadString());

                        profesor.Activo = reader.ReadBoolean();
                        datos.Profesores.Add(profesor);
                    }

                    int cantidadCursos = reader.ReadInt32();
                    for (int i = 0; i < cantidadCursos; i++)
                    {
                        Curso curso = new Curso(
                            reader.ReadString(),
                            reader.ReadString(),
                            reader.ReadInt32(),
                            reader.ReadString());

                        curso.Activo = reader.ReadBoolean();
                        datos.Cursos.Add(curso);
                    }

                    int cantidadInscripciones = reader.ReadInt32();
                    for (int i = 0; i < cantidadInscripciones; i++)
                    {
                        Inscripcion inscripcion = new Inscripcion(
                            reader.ReadString(),
                            reader.ReadString());

                        inscripcion.Activo = reader.ReadBoolean();
                        int totalNotas = reader.ReadInt32();
                        for (int j = 0; j < totalNotas; j++)
                        {
                            inscripcion.AgregarNota(reader.ReadDecimal());
                        }

                        datos.Inscripciones.Add(inscripcion);
                    }
                }
            }
            catch (Exception)
            {
                return new DatosSistema();
            }

            return datos;
        }

        public static void Guardar(DatosSistema datos)
        {
            if (datos == null)
                datos = new DatosSistema();

            try
            {
                using (BinaryWriter writer = new BinaryWriter(File.Open(RutaArchivo, FileMode.Create, FileAccess.Write)))
                {
                    writer.Write(datos.Usuarios.Count);
                    foreach (Usuario u in datos.Usuarios)
                    {
                        writer.Write(u.NombreUsuario);
                        writer.Write(u.ContrasenaHash);
                        writer.Write(u.Rol);
                        writer.Write(u.EsUsuarioInicialProtegido);
                        writer.Write(u.Activo);
                    }

                    writer.Write(datos.Estudiantes.Count);
                    foreach (Estudiante e in datos.Estudiantes)
                    {
                        writer.Write(e.Nombre);
                        writer.Write(e.Documento);
                        writer.Write(e.Correo);
                        writer.Write(e.Edad);
                        writer.Write(e.Carrera);
                        writer.Write(e.Activo);
                    }

                    writer.Write(datos.Profesores.Count);
                    foreach (Profesor p in datos.Profesores)
                    {
                        writer.Write(p.Nombre);
                        writer.Write(p.Documento);
                        writer.Write(p.Correo);
                        writer.Write(p.Especialidad);
                        writer.Write(p.Activo);
                    }

                    writer.Write(datos.Cursos.Count);
                    foreach (Curso c in datos.Cursos)
                    {
                        writer.Write(c.Codigo);
                        writer.Write(c.Nombre);
                        writer.Write(c.Creditos);
                        writer.Write(c.Carrera);
                        writer.Write(c.Activo);
                    }

                    writer.Write(datos.Inscripciones.Count);
                    foreach (Inscripcion i in datos.Inscripciones)
                    {
                        writer.Write(i.DocumentoEstudiante);
                        writer.Write(i.CodigoCurso);
                        writer.Write(i.Activo);
                        writer.Write(i.Notas.Count);
                        foreach (decimal nota in i.Notas)
                        {
                            writer.Write(nota);
                        }
                    }
                }
            }
            catch (Exception)
            {
                throw new IOException("No se pudo guardar la información del sistema.");
            }
        }
    }
}