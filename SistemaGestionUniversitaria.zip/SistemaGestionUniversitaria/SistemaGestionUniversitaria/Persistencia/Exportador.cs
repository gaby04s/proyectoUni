﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SistemaGestionUniversitaria.Persistencia
{
    public static class Exportador
    {
        public static string ExportarTexto(List<string> lineas, string nombreArchivo)
        {
            if (lineas == null || lineas.Count == 0)
                throw new InvalidOperationException("No hay datos para exportar.");

            string ruta = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, nombreArchivo);

            try
            {
                using (StreamWriter writer = new StreamWriter(ruta, false, Encoding.UTF8))
                {
                    foreach (string linea in lineas)
                    {
                        writer.WriteLine(linea);
                    }
                }
            }
            catch
            {
                throw new IOException("No se pudo crear el archivo de exportación.");
            }

            return ruta;
        }

        public static string ExportarCsv(List<string> lineas, string nombreArchivo)
        {
            if (lineas == null || lineas.Count == 0)
                throw new InvalidOperationException("No hay datos para exportar.");

            string ruta = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, nombreArchivo);

            try
            {
                using (StreamWriter writer = new StreamWriter(ruta, false, Encoding.UTF8))
                {
                    foreach (string linea in lineas)
                    {
                        writer.WriteLine(linea);
                    }
                }
            }
            catch
            {
                throw new IOException("No se pudo crear el archivo CSV.");
            }

            return ruta;
        }
    }
}