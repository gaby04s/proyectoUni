﻿using SistemaGestionUniversitaria.Utilidades;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SistemaGestionUniversitaria.Persistencia
{
    public static class ArchivoLogs
    {
        public static string RutaArchivo = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "logsUniversidad.bin");

        public static List<LogEntry> Cargar()
        {
            List<LogEntry> lista = new List<LogEntry>();

            if (!File.Exists(RutaArchivo))
                return lista;

            try
            {
                using (BinaryReader reader = new BinaryReader(File.Open(RutaArchivo, FileMode.Open, FileAccess.Read)))
                {
                    int cantidad = reader.ReadInt32();

                    for (int i = 0; i < cantidad; i++)
                    {
                        LogEntry entry = new LogEntry();
                        entry.FechaHora = DateTime.FromBinary(reader.ReadInt64());
                        entry.Usuario = reader.ReadString();
                        entry.Accion = reader.ReadString();
                        entry.RegistroAfectado = reader.ReadString();
                        entry.Detalle = reader.ReadString();
                        lista.Add(entry);
                    }
                }
            }
            catch
            {
                return new List<LogEntry>();
            }

            return lista;
        }

        public static void Guardar(List<LogEntry> logEntries)
        {
            if (logEntries == null)
                logEntries = new List<LogEntry>();

            try
            {
                using (BinaryWriter writer = new BinaryWriter(File.Open(RutaArchivo, FileMode.Create, FileAccess.Write)))
                {
                    writer.Write(logEntries.Count);

                    foreach (LogEntry entry in logEntries)
                    {
                        writer.Write(entry.FechaHora.ToBinary());
                        writer.Write(entry.Usuario ?? "");
                        writer.Write(entry.Accion ?? "");
                        writer.Write(entry.RegistroAfectado ?? "");
                        writer.Write(entry.Detalle ?? "");
                    }
                }
            }
            catch
            {
                throw new IOException("No se pudo guardar el archivo de logs.");
            }
        }

        public static void AgregarLog(LogEntry entrada)
        {
            List<LogEntry> logs = Cargar();
            logs.Add(entrada);
            Guardar(logs);
        }

        public static void MostrarLogs()
        {
            List<LogEntry> logs = Cargar();

            if (logs.Count == 0)
            {
                Console.WriteLine("No hay logs registrados.");
                return;
            }

            foreach (LogEntry entry in logs)
            {
                Console.WriteLine(entry.ToString());
            }
        }
    }
}