﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace SistemaGestionUniversitaria.Validacion
{
    public static class ValidadorNombre
    {
        public static string Validar(string valor)
        {
            valor = NormalizadorTexto.ValidarObligatorio(
                valor, "El nombre", 2, 80);

            // Permite letras con acentos, ñ, espacios, apóstrofes y guiones.
            // No permite números ni símbolos ajenos a un nombre.
            if (!Regex.IsMatch(
                valor,
                @"^[\p{L}][\p{L}\p{M} '-]*$"))
            {
                throw new ArgumentException(
                    "El nombre solo puede contener letras, espacios, " +
                    "apóstrofes y guiones.");
            }

            return valor;
        }
    }
}