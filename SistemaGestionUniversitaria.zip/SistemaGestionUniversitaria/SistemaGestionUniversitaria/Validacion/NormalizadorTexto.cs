﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace SistemaGestionUniversitaria.Validacion
{
    public static class NormalizadorTexto
    {
        public static string Normalizar(string texto)
        {
            return texto == null ? string.Empty : texto.Trim();
        }

        public static string ValidarObligatorio(
            string texto,
            string nombreCampo,
            int longitudMinima,
            int longitudMaxima)
        {
            string normalizado = Normalizar(texto);

            if (normalizado.Length == 0)
            {
                throw new System.ArgumentException(
                    nombreCampo + " es obligatorio.");
            }

            if (normalizado.Length < longitudMinima ||
                normalizado.Length > longitudMaxima)
            {
                throw new System.ArgumentException(
                    nombreCampo + " debe tener entre " +
                    longitudMinima + " y " + longitudMaxima +
                    " caracteres.");
            }

            return normalizado;
        }

        public static string ValidarDescripcion(string texto, string campo)
        {
            string valor = ValidarObligatorio(texto, campo, 2, 100);

            if (!Regex.IsMatch(
                    valor,
                    @"^[\p{L}\p{M}0-9][\p{L}\p{M}0-9\s.'’&()/#+:-]*$") ||
                !Regex.IsMatch(valor, @"\p{L}"))
            {
                throw new System.ArgumentException(
                    campo + " debe incluir letras y no puede contener símbolos no permitidos.");
            }

            return valor;
        }
    }
}
