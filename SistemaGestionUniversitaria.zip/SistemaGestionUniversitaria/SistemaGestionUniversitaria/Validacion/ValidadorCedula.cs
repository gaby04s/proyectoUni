﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace SistemaGestionUniversitaria.Validacion
{
    public static class ValidadorCedula
    {
        public static string Validar(string valor)
        {
            valor = NormalizadorTexto.ValidarObligatorio(
                valor, "La identificación", 6, 20);

            // Validación general. El formato exacto debe ajustarse
            // al país donde se presentará el proyecto.
            if (!Regex.IsMatch(valor, @"^[A-Za-z0-9-]+$"))
            {
                throw new ArgumentException(
                    "La identificación solo puede contener letras, " +
                    "números y guiones.");
            }

            return valor;
        }
    }
}
