﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SistemaGestionUniversitaria.Validacion
{
    public static class ValidadorNota
    {
        public static decimal Validar(decimal nota)
        {
            if (nota < 0 || nota > 100)
            {
                throw new ArgumentOutOfRangeException(
                    "nota",
                    "La nota debe estar entre 0 y 100.");
            }

            return nota;
        }

        public static bool IntentarConvertir(string texto, out decimal nota)
        {
            nota = 0;

            if (string.IsNullOrWhiteSpace(texto))
            {
                return false;
            }

           
            return decimal.TryParse(
                texto.Trim(),
                System.Globalization.NumberStyles.Number,
                System.Globalization.CultureInfo.CurrentCulture,
                out nota);
        }
    }
}