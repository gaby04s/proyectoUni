﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;

namespace SistemaGestionUniversitaria.Validacion
{
    public static class ValidadorCorreo
    {
            public static string Validar(string valor)
            {
                valor = NormalizadorTexto.ValidarObligatorio(
                    valor, "El correo", 5, 254);

                try
                {
                    MailAddress direccion = new MailAddress(valor);

                    // Rechaza valores como "Nombre <correo@dominio.com>".
                    if (!string.Equals(
                        direccion.Address,
                        valor,
                        StringComparison.OrdinalIgnoreCase))
                    {
                        throw new ArgumentException(
                            "El formato del correo no es válido.");
                    }
                }
                catch (FormatException)
                {
                    throw new ArgumentException(
                        "El formato del correo no es válido.");
                }

                return valor;
            }
        }
    }
