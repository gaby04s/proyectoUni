﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace SistemaGestionUniversitaria.Validacion
{
    public static class ValidadorTelefono
    {
        public static string Validar(string valor)
        {
            valor = NormalizadorTexto.ValidarObligatorio(
                valor, "El teléfono", 7, 20);

            if (!Regex.IsMatch(valor, @"^[0-9+()\-\s]+$"))
            {
                throw new ArgumentException(
                    "El teléfono solo puede contener números, espacios " +
                    "y los símbolos +, -, (, ).");
            }

            int cantidadDigitos = Regex.Replace(valor, @"\D", "").Length;

            if (cantidadDigitos < 7 || cantidadDigitos > 15)
            {
                throw new ArgumentException(
                    "El teléfono debe contener entre 7 y 15 dígitos.");
            }

            return valor;
        }
    }
}