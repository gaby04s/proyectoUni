﻿using SistemaGestionUniversitaria.Modelo;
using SistemaGestionUniversitaria.Persistencia;
using SistemaGestionUniversitaria.Utilidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SistemaGestionUniversitaria.App
{
    public static class Autenticacion
    {
        public static bool IniciarSesion()
        {
            DatosSistema datos = ArchivoDatos.Cargar();

            if (datos == null)
                datos = new DatosSistema();

            if (datos.Usuarios == null)
                datos.Usuarios = new List<Usuario>();

            if (datos.Usuarios.Count == 0)
            {
                Usuario usuarioInicial = new Usuario("Victor", "Vl22050*/", "Administrador", true);
                datos.Usuarios.Add(usuarioInicial);
                ArchivoDatos.Guardar(datos);
            }

            const int maxIntentos = 3;

            for (int intento = 1; intento <= maxIntentos; intento++)
            {
                Console.Write("Usuario: ");
                string usuario = Console.ReadLine();

                Console.Write("Contraseña: ");
                string contrasena = LeerPasswordOculta();

                bool correcto = false;

                foreach (Usuario cuenta in datos.Usuarios)
                {
                    if (cuenta != null && cuenta.Activo && cuenta.ValidarCredenciales(usuario, contrasena))
                    {
                        correcto = true;
                        Log.Registrar(cuenta.NombreUsuario, "LOGIN_EXITO", cuenta.NombreUsuario, "Inicio de sesión correcto.");
                        Console.WriteLine();
                        Console.WriteLine("Inicio de sesión correcto.");
                        return true;
                    }
                }

                Log.Registrar(usuario ?? "desconocido", "LOGIN_FALLIDO", usuario ?? "desconocido", "Intento fallido.");

                int restantes = maxIntentos - intento;
                if (restantes > 0)
                {
                    Console.WriteLine();
                    Console.WriteLine("Credenciales incorrectas. Intentos restantes: " + restantes);
                }
            }

            Console.WriteLine();
            Console.WriteLine("Se agotaron los 3 intentos. El programa se cerrará.");
            return false;
        }

        private static string LeerPasswordOculta()
        {
            string texto = string.Empty;

            while (true)
            {
                ConsoleKeyInfo tecla = Console.ReadKey(true);

                if (tecla.Key == ConsoleKey.Enter)
                {
                    Console.WriteLine();
                    return texto;
                }

                if (tecla.Key == ConsoleKey.Backspace)
                {
                    if (texto.Length > 0)
                    {
                        texto = texto.Substring(0, texto.Length - 1);
                        Console.Write("\b \b");
                    }
                    continue;
                }

                if (!char.IsControl(tecla.KeyChar))
                {
                    texto += tecla.KeyChar;
                    Console.Write("*");
                }
            }
        }
    }
}