﻿using System;
using System.Collections.Generic;
using SistemaGestionUniversitaria.Modelo;
using SistemaGestionUniversitaria.Persistencia;
using SistemaGestionUniversitaria.Servicio;
using SistemaGestionUniversitaria.Utilidades;

namespace SistemaGestionUniversitaria.App
{
    public class Menu
    {
        private RegistroUniversidad registro;

        public Menu()
        {
            registro = new RegistroUniversidad();
        }

        public void Iniciar()
        {
            bool continuar = true;

            while (continuar)
            {
                Console.Clear();
                Console.WriteLine("==============================================");
                Console.WriteLine("      SISTEMA DE GESTION UNIVERSITARIA");
                Console.WriteLine("==============================================");
                Console.WriteLine("1. Agregar estudiante");
                Console.WriteLine("2. Listar estudiantes");
                Console.WriteLine("3. Buscar estudiante");
                Console.WriteLine("4. Editar estudiante");
                Console.WriteLine("5. Desactivar estudiante");
                Console.WriteLine("6. Reactivar estudiante");
                Console.WriteLine("7. Agregar profesor");
                Console.WriteLine("8. Listar profesores");
                Console.WriteLine("9. Buscar profesor");
                Console.WriteLine("10. Editar profesor");
                Console.WriteLine("11. Desactivar profesor");
                Console.WriteLine("12. Reactivar profesor");
                Console.WriteLine("13. Agregar curso");
                Console.WriteLine("14. Listar cursos");
                Console.WriteLine("15. Agregar inscripción");
                Console.WriteLine("16. Registrar nota");
                Console.WriteLine("17. Exportar datos");
                Console.WriteLine("18. Ver logs");
                Console.WriteLine("19. Cerrar sesión");
                Console.WriteLine("20. Salir");
                Console.WriteLine("==============================================");

                int opcion = Entrada.LeerEntero("Seleccione una opción: ");

                try
                {
                    switch (opcion)
                    {
                        case 1:
                            AgregarEstudiante();
                            break;
                        case 2:
                            ListarEstudiantes();
                            break;
                        case 3:
                            BuscarEstudiante();
                            break;
                        case 4:
                            EditarEstudiante();
                            break;
                        case 5:
                            DesactivarEstudiante();
                            break;
                        case 6:
                            ReactivarEstudiante();
                            break;
                        case 7:
                            AgregarProfesor();
                            break;
                        case 8:
                            ListarProfesores();
                            break;
                        case 9:
                            BuscarProfesor();
                            break;
                        case 10:
                            EditarProfesor();
                            break;
                        case 11:
                            DesactivarProfesor();
                            break;
                        case 12:
                            ReactivarProfesor();
                            break;
                        case 13:
                            AgregarCurso();
                            break;
                        case 14:
                            ListarCursos();
                            break;
                        case 15:
                            AgregarInscripcion();
                            break;
                        case 16:
                            RegistrarNota();
                            break;
                        case 17:
                            ExportarDatos();
                            break;
                        case 18:
                            MostrarLogs();
                            break;
                        case 19:
                            Log.Registrar("Victor", "CERRAR_SESION", "Sistema", "Se cerró la sesión actual.");
                            continuar = false;
                            Console.WriteLine("Sesión cerrada.");
                            break;
                        case 20:
                            continuar = false;
                            Console.WriteLine("Gracias por usar el sistema.");
                            break;
                        default:
                            Console.WriteLine("Opción no válida.");
                            break;
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Error: " + ex.Message);
                }

                if (continuar)
                {
                    Console.WriteLine("Presione una tecla para continuar...");
                    Console.ReadKey();
                }
            }
        }

        private void AgregarEstudiante()
        {
            string nombre = Entrada.LeerTexto("Nombre: ");
            string documento = Entrada.LeerTexto("Documento: ");
            string correo = Entrada.LeerTexto("Correo: ");
            int edad = Entrada.LeerEntero("Edad: ");
            string carrera = Entrada.LeerTexto("Carrera: ");

            Estudiante e = new Estudiante(nombre, documento, correo, edad, carrera);
            registro.AgregarEstudiante(e);
            Console.WriteLine("Estudiante agregado correctamente.");
        }

        private void ListarEstudiantes()
        {
            List<Estudiante> lista = registro.ListarEstudiantes();
            if (lista.Count == 0)
            {
                Console.WriteLine("No hay estudiantes registrados.");
                return;
            }

            foreach (Estudiante e in lista)
            {
                Console.WriteLine(e.GenerarResumen());
            }
        }

        private void BuscarEstudiante()
        {
            string documento = Entrada.LeerTexto("Documento: ");
            Estudiante e = registro.BuscarEstudiante(documento);

            if (e == null)
            {
                Console.WriteLine("Estudiante no encontrado.");
                return;
            }

            Console.WriteLine(e.GenerarResumen());
        }

        private void EditarEstudiante()
        {
            string documento = Entrada.LeerTexto("Documento: ");
            string nombre = Entrada.LeerTexto("Nuevo nombre: ");
            string correo = Entrada.LeerTexto("Nuevo correo: ");
            int edad = Entrada.LeerEntero("Nueva edad: ");
            string carrera = Entrada.LeerTexto("Nueva carrera: ");

            registro.EditarEstudiante(documento, nombre, correo, edad, carrera);
            Console.WriteLine("Estudiante actualizado.");
        }

        private void DesactivarEstudiante()
        {
            string documento = Entrada.LeerTexto("Documento: ");
            bool confirmado = Entrada.LeerConfirmacion("¿Desea desactivar este estudiante?");
            if (!confirmado)
            {
                Console.WriteLine("Operación cancelada.");
                return;
            }

            registro.DesactivarEstudiante(documento);
            Console.WriteLine("Estudiante desactivado.");
        }

        private void ReactivarEstudiante()
        {
            string documento = Entrada.LeerTexto("Documento: ");
            registro.ReactivarEstudiante(documento);
            Console.WriteLine("Estudiante reactivado.");
        }

        private void AgregarProfesor()
        {
            string nombre = Entrada.LeerTexto("Nombre: ");
            string documento = Entrada.LeerTexto("Documento: ");
            string correo = Entrada.LeerTexto("Correo: ");
            string especialidad = Entrada.LeerTexto("Especialidad: ");

            Profesor p = new Profesor(nombre, documento, correo, especialidad);
            registro.AgregarProfesor(p);
            Console.WriteLine("Profesor agregado correctamente.");
        }

        private void ListarProfesores()
        {
            List<Profesor> lista = registro.ListarProfesores();
            if (lista.Count == 0)
            {
                Console.WriteLine("No hay profesores registrados.");
                return;
            }

            foreach (Profesor p in lista)
            {
                Console.WriteLine(p.GenerarResumen());
            }
        }

        private void BuscarProfesor()
        {
            string documento = Entrada.LeerTexto("Documento: ");
            Profesor p = registro.BuscarProfesor(documento);

            if (p == null)
            {
                Console.WriteLine("Profesor no encontrado.");
                return;
            }

            Console.WriteLine(p.GenerarResumen());
        }

        private void EditarProfesor()
        {
            string documento = Entrada.LeerTexto("Documento: ");
            string nombre = Entrada.LeerTexto("Nuevo nombre: ");
            string correo = Entrada.LeerTexto("Nuevo correo: ");
            string especialidad = Entrada.LeerTexto("Nueva especialidad: ");

            registro.EditarProfesor(documento, nombre, correo, especialidad);
            Console.WriteLine("Profesor actualizado.");
        }

        private void DesactivarProfesor()
        {
            string documento = Entrada.LeerTexto("Documento: ");
            bool confirmado = Entrada.LeerConfirmacion("¿Desea desactivar este profesor?");
            if (!confirmado)
            {
                Console.WriteLine("Operación cancelada.");
                return;
            }

            registro.DesactivarProfesor(documento);
            Console.WriteLine("Profesor desactivado.");
        }

        private void ReactivarProfesor()
        {
            string documento = Entrada.LeerTexto("Documento: ");
            registro.ReactivarProfesor(documento);
            Console.WriteLine("Profesor reactivado.");
        }

        private void AgregarCurso()
        {
            string codigo = Entrada.LeerTexto("Código del curso: ");
            string nombre = Entrada.LeerTexto("Nombre del curso: ");
            int creditos = Entrada.LeerEntero("Créditos: ");
            string carrera = Entrada.LeerTexto("Carrera: ");

            Curso c = new Curso(codigo, nombre, creditos, carrera);
            registro.AgregarCurso(c);
            Console.WriteLine("Curso agregado correctamente.");
        }

        private void ListarCursos()
        {
            List<Curso> lista = registro.ListarCursos();
            if (lista.Count == 0)
            {
                Console.WriteLine("No hay cursos registrados.");
                return;
            }

            foreach (Curso c in lista)
            {
                Console.WriteLine(c.ToString());
            }
        }

        private void AgregarInscripcion()
        {
            string documentoEstudiante = Entrada.LeerTexto("Documento del estudiante: ");
            string codigoCurso = Entrada.LeerTexto("Código del curso: ");

            Estudiante e = registro.BuscarEstudiante(documentoEstudiante);
            Curso c = registro.BuscarCurso(codigoCurso);

            if (e == null)
            {
                Console.WriteLine("No existe el estudiante.");
                return;
            }

            if (c == null)
            {
                Console.WriteLine("No existe el curso.");
                return;
            }

            Inscripcion inscripcion = new Inscripcion(documentoEstudiante, codigoCurso);
            registro.AgregarInscripcion(inscripcion);
            Console.WriteLine("Inscripción registrada.");
        }

        private void RegistrarNota()
        {
            string documentoEstudiante = Entrada.LeerTexto("Documento del estudiante: ");
            string codigoCurso = Entrada.LeerTexto("Código del curso: ");
            decimal nota = Entrada.LeerDecimal("Nota (0-100): ");

            registro.RegistrarNota(documentoEstudiante, codigoCurso, nota);
            Console.WriteLine("Nota registrada.");
        }

        private void ExportarDatos()
        {
            Console.WriteLine("Seleccione el módulo:");
            Console.WriteLine("1. Estudiantes");
            Console.WriteLine("2. Profesores");
            Console.WriteLine("3. Todo");
            int modulo = Entrada.LeerEntero("Opción: ");

            Console.WriteLine("Seleccione el filtro:");
            Console.WriteLine("1. Activos");
            Console.WriteLine("2. Inactivos");
            Console.WriteLine("3. Todos");
            int filtro = Entrada.LeerEntero("Opción: ");

            bool activos = (filtro == 1);
            bool inactivos = (filtro == 2);

            List<string> lineas = new List<string>();

            try
            {
                if (modulo == 1)
                {
                    lineas = registro.ExportarEstudiantes(activos, inactivos);
                    if (lineas.Count == 0)
                    {
                        Console.WriteLine("No hay datos para exportar en la selección actual.");
                        return;
                    }

                    string ruta = Exportador.ExportarTexto(lineas, "exportacion_estudiantes.txt");
                    Console.WriteLine("Archivo exportado en: " + ruta);
                    Log.Registrar("Victor", "EXPORTAR_DATO", "Estudiantes", "Se exportó la información de estudiantes en " + ruta);
                }
                else if (modulo == 2)
                {
                    lineas = registro.ExportarProfesores(activos, inactivos);
                    if (lineas.Count == 0)
                    {
                        Console.WriteLine("No hay datos para exportar en la selección actual.");
                        return;
                    }

                    string ruta = Exportador.ExportarTexto(lineas, "exportacion_profesores.txt");
                    Console.WriteLine("Archivo exportado en: " + ruta);
                    Log.Registrar("Victor", "EXPORTAR_DATO", "Profesores", "Se exportó la información de profesores en " + ruta);
                }
                else if (modulo == 3)
                {
                    lineas = registro.ExportarTodo(activos, inactivos);
                    if (lineas.Count == 0)
                    {
                        Console.WriteLine("No hay datos para exportar en la selección actual.");
                        return;
                    }

                    string ruta = Exportador.ExportarTexto(lineas, "exportacion_total.txt");
                    Console.WriteLine("Archivo exportado en: " + ruta);
                    Log.Registrar("Victor", "EXPORTAR_DATO", "Sistema", "Se exportó el sistema completo en " + ruta);
                }
                else
                {
                    Console.WriteLine("Opción de módulo inválida.");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("No se pudo exportar: " + ex.Message);
            }
        }

        private void MostrarLogs()
        {
            Console.WriteLine("=== LOGS ===");
            List<LogEntry> logs = ArchivoLogs.Cargar();

            if (logs.Count == 0)
            {
                Console.WriteLine("No existe historial de logs.");
                return;
            }

            foreach (LogEntry log in logs)
            {
                Console.WriteLine(log.ToString());
            }
        }
    }
}