﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SistemaGestionUniversitaria.App
{
    public static class Entrada
    {
        public static string LeerTexto(string mensaje)
        {
            Console.Write(mensaje);
            string valor = Console.ReadLine();

            return valor == null ? string.Empty : valor.Trim();
        }

        public static int LeerEntero(string mensaje)
        {
            while (true)
            {
                Console.Write(mensaje);
                string valor = Console.ReadLine();

                int numero;
                if (int.TryParse(valor, out numero))
                    return numero;

                Console.WriteLine("Entrada inválida. Debe ser un número entero.");
            }
        }

        public static decimal LeerDecimal(string mensaje)
        {
            while (true)
            {
                Console.Write(mensaje);
                string valor = Console.ReadLine();

                decimal numero;
                if (decimal.TryParse(valor, out numero))
                    return numero;

                Console.WriteLine("Entrada inválida. Debe ser un número decimal.");
            }
        }

        public static bool LeerConfirmacion(string mensaje)
        {
            while (true)
            {
                Console.Write(mensaje + " (S/N): ");
                string respuesta = Console.ReadLine();

                if (string.Equals(respuesta, "S", StringComparison.OrdinalIgnoreCase))
                    return true;

                if (string.Equals(respuesta, "N", StringComparison.OrdinalIgnoreCase))
                    return false;

                Console.WriteLine("Respuesta inválida. Debe escribir S o N.");
            }
        }
    }
}