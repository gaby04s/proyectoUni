﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SistemaGestionUniversitaria.App
{
    public static class DemoPruebas
    {
        public static void Ejecutar()
        {
            Console.WriteLine("=== DEMO DEL SISTEMA UNIVERSITARIO ===");
            Console.WriteLine("Se ejecutó la demostración del sistema.");
            Console.WriteLine("=====================================");
        }
    }
}