﻿using SistemaGestionUniversitaria.Modelo;
using SistemaGestionUniversitaria.Servicio;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SistemaGestionUniversitaria.Estudiantes
{
    public class ListarEstudiantes
    {
        public static void Ejecutar(RegistroUniversidad registro)
        {
            try
            {
                List<Estudiante> estudiantes = registro.ListarEstudiantes();
                if (estudiantes.Count == 0)
                {
                    Console.WriteLine("No hay estudiantes registrados.");
                    return;
                }

                foreach (Estudiante estudiante in estudiantes)
                {
                    Console.WriteLine(estudiante.GenerarResumen());
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error al listar estudiantes: " + ex.Message);
            }
        }
    }
}
