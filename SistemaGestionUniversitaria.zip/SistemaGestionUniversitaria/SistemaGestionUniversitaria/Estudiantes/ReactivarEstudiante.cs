﻿using SistemaGestionUniversitaria.Servicio;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SistemaGestionUniversitaria.Estudiantes
{

    public class ReactivarEstudiante
    {
        public static void Ejecutar(RegistroUniversidad registro, string documento)
        {
            try
            {
                registro.ReactivarEstudiante(documento);
                Console.WriteLine("Estudiante reactivado.");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error al reactivar estudiante: " + ex.Message);
            }
        }
    }
}