﻿using SistemaGestionUniversitaria.Servicio;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SistemaGestionUniversitaria.Estudiantes
{
    public class DesactivarEstudiante
    {
        public static void Ejecutar(RegistroUniversidad registro, string documento)
        {
            try
            {
                registro.DesactivarEstudiante(documento);
                Console.WriteLine("Estudiante desactivado.");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error al desactivar estudiante: " + ex.Message);
            }
        }
    }
}