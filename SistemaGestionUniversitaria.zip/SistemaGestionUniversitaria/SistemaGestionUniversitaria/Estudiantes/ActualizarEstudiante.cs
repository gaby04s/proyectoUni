﻿using SistemaGestionUniversitaria.Servicio;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SistemaGestionUniversitaria.Estudiantes
{
    public class ActualizarEstudiante
    {
        public static void Ejecutar(RegistroUniversidad registro, string documento, string nombre, string correo, int edad, string carrera)
        {
            try
            {
                registro.EditarEstudiante(documento, nombre, correo, edad, carrera);
                Console.WriteLine("Estudiante actualizado.");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error al actualizar estudiante: " + ex.Message);
            }
        }
    }
}