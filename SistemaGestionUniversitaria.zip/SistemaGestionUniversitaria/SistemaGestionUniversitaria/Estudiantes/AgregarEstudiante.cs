﻿using SistemaGestionUniversitaria.Modelo;
using SistemaGestionUniversitaria.Servicio;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SistemaGestionUniversitaria.Estudiantes
{
    public class AgregarEstudiante
    {
        public static void Ejecutar(RegistroUniversidad registro, string nombre, string documento, string correo, int edad, string carrera)
        {
            try
            {
                Estudiante estudiante = new Estudiante(nombre, documento, correo, edad, carrera);
                registro.AgregarEstudiante(estudiante);
                Console.WriteLine("Estudiante agregado.");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error al agregar estudiante: " + ex.Message);
            }
        }
    }
}