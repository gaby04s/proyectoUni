﻿using SistemaGestionUniversitaria.Modelo;
using SistemaGestionUniversitaria.Servicio;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SistemaGestionUniversitaria.Estudiantes
{
    public class BuscarEstudiante
    {
        public static void Ejecutar(RegistroUniversidad registro, string documento)
        {
            try
            {
                Estudiante estudiante = registro.BuscarEstudiante(documento);
                if (estudiante == null)
                {
                    Console.WriteLine("Estudiante no encontrado.");
                    return;
                }

                Console.WriteLine(estudiante.GenerarResumen());
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error al buscar estudiante: " + ex.Message);
            }
        }
    }
}